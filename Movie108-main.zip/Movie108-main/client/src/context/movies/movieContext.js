import { createContext } from "react";

const movieContext = createContext();

export default movieContext;
