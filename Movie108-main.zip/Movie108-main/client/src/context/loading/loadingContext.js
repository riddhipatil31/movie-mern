import { createContext } from "react";

const loadingContext = createContext();

export default loadingContext;
